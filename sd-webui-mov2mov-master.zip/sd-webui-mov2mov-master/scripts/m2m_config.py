mov2mov_outpath_samples = 'outputs/mov2mov-images'
mov2mov_output_dir = 'outputs/mov2mov-videos'
